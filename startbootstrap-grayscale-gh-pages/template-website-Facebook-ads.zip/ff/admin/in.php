<?php

require "../config/db.php";
    $sql = " SELECT * FROM ipa ";
    $q = mysqli_query( $mysqli, $sql );
    $num = mysqli_num_rows( $q );
    mysqli_close( $mysqli );
?> <br>
      
      
</button>
       
      <?php 
                   $stmt = $conn->query("SELECT * FROM ipa");
                    $stmt->execute();
                    $users = $stmt->fetchAll();
                       

                    if (!$users) {
                       
                    } else {
                    foreach($users as $user)  {  
                ?>
                    <table> 
                    <tr>
                    <td><?php echo $user['id']; ?> </td>
                    <td><?php echo $user['uipa']; ?> </td>
                    <td><?php echo $user['time']; ?></td>
                    </tr>
                    </table>
                
             <?php  }} ?>
      </div>
     


