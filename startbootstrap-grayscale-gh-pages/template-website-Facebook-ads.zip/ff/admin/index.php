<?php
session_start();

require "../config/db.php"; 
if(!isset($_SESSION['ok'])){
    $_SESSION['error'] = 'กรุณาใส่ข้อมูลถูกต้อง';
    header("location: login.php");
   
   
}
if(isset($_POST['submit'])){
    $namea=$_SERVER['REMOTE_ADDR'];
    $sql = $conn->prepare("INSERT INTO users(namea) VALUES(:namea)");
    $sql->bindParam(":namea", $namea);
    $sql->execute();

    If($sql){
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
}



if (isset($_GET['ipa'])) {
    $delete_id = $_GET['delete'];
    $deletestmt = $conn->query("DELETE FROM ipa");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}
if (isset($_GET['ipb'])) {
    $delete_id = $_GET['delete'];
    $deletestmt = $conn->query("DELETE FROM ipb");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}
if (isset($_GET['web_a'])) {
    $delete_id = $_GET['delete'];
    $deletestmt = $conn->query("DELETE FROM web_a");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
}    
if (isset($_GET['users'])) {
    $delete_id = $_GET['delete'];
    $deletestmt = $conn->query("DELETE FROM users");
    $deletestmt->execute();

    if ($deletestmt) {
       
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}
?>

<hr>
        <?php if (isset($_SESSION['success'])) { ?>
            <div class="alert alert-success">
                <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']); 
                ?>
            </div>
        <?php } ?>
        <?php if (isset($_SESSION['error'])) { ?>
            <div class="alert alert-danger">
                <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']); 
                ?>
            </div>
        <?php } ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Document</title>
 <link rel="stylesheet" href="style.css">
 <style>
.web_a {
   border: 2px solid black;
    width: 400px;
    position: fixed;
    top: 200px;
    left: 35%;
    height: 500px;
}
body {
    position: relative;
   
}
#box {
      
   
    width: 500px;
    
position: absolute;
left: 100px;
top: 120px;

}
#boxx {
      
 
    width: 500px;
    
position: absolute;
left: 1300px;
top: 120px;

}
 </style>
</head>
<body>





    
    
   







    <div class="container">

<div class="text-center">
<form action="xxx.php" method="get">

<button type="submit" class="btn btn-primary" name="submit">ดูรายละเอียด IP</button>
<button type="submit" class="btn btn-warning" name="xxx" >ปิดรายละเอียด IP</button>
</form>
</div>





<div class="d-flex justify-content-between" id="myxxx" >


<div class="h1" >





    
</div>


<div class="position-relative py-2 px-4 text-bg-secondary border border-secondary rounded-pill">
</div>

<button type="button" class="btn btn-primary position-relative">
</button>
  






</div>

<div class="web_a">

<div class="text-center" ><div><form method="get"><button class="btn btn-info" type="submit"name="ipa">ลบ ipa</button>
<button class="btn btn-danger" type="submit"name="ipb">ลบ ipb</button></form>


</div>

<form action="index.php" method="post"><button class="btn btn-secondary" type="submit"name="submit">เปิดหน้าเทา</button></form>


<form method="get"><button class="btn btn-success" type="submit"name="users">เปิดหน้าขาว</button></form>
<!-------------------------------------------------web_a-------------------------------->


<?php

$stmt = $conn->query("SELECT * FROM users");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

 if(isset($row['namea'])){ ?>

<div class="text-bg-secondary p-3">หน้าเทาเปิดอยู่</div>


<?php } else {?>


    <div class="text-bg-success p-3">หน้าขาวเปิดอยู่</div>



  <?php } ?>


    <!-- Scrollable modal -->
</div>




<!-- Button trigger modal -->


</div>











<?php  require "../config/db.php"; 
         $stmt = $conn->query("SELECT * FROM ipb");
         $stmt->execute();
         $users = $stmt->fetchAll();
         $num_b =$stmt->rowCount();
     ?>
<?php  require "../config/db.php"; 
         $stmt = $conn->query("SELECT * FROM ipa");
         $stmt->execute();
         $users = $stmt->fetchAll();
         $num_a =$stmt->rowCount();

     ?>
<?php $num = $num_b*100/$num_a;

?>
</div>
</div>
<div class="fixed-bottom m-5">


<?php if($num >= 50){ ?>
    <div class="alert alert-success text-center" id="mit"><h4>คุณภาพดีมากครับ (กราฟฟิก)</h4></div>
    <?php  } else if($num >= 40){ ?>
        <div class="alert alert-primary text-center" id="mit"><h4>คุณภาพดีครับ (กราฟฟิก)</h4></div>
    <?php  } else if($num >= 30){ ?>
        <div class="alert alert-info text-center" id="mit"><h4>คุณภาพปานกลางครับ (กราฟฟิก)</h4></div>
        <?php } else if($num >= 20){ ?>
            <div class="alert alert-warning text-center" id="mit"><h4>คุณภาพแย่ครับ (กราฟฟิก)</h4></div>
            <?php } else if($num >= 20){ ?>
            <div class="alert alert-danger  text-center" id="mit"><h4>คุณภาพเปลี่ยนด่วนครับ (กราฟฟิก)</h4></div>
            <?php } ?>






</div></div>









<input type="hidden" id="xxx">
<script src="js/xxx.js"></script>

</body>
</html>