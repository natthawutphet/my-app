<?php 
session_start();
require "../config/db.php";


if (isset($_POST['xxx'])) {


    $xxx = $_POST['xxx'];

$sql = $conn->prepare("INSERT INTO webdark(xxx) VALUES(:xxx)");
$sql->bindParam(":xxx", $xxx);
$sql->execute();

if ($sql) {
    $_SESSION['success'] = "urldark successfully";
    header("location: index.php");
} else {
    $_SESSION['error'] = "Data has not been inserted successfully";
    header("location: index.php");
}

}
?>