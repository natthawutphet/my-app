<?php 
session_start();
require "../config/db.php";

if (isset($_POST['submit'])) {


    $name = $_POST['name'];

$sql = $conn->prepare("INSERT INTO web_a(name) VALUES(:name)");
$sql->bindParam(":name", $name);
$sql->execute();

if ($sql) {
    $_SESSION['success'] = "Data has been inserted successfully";
    header("location: index.php");
} else {
    $_SESSION['error'] = "Data has not been inserted successfully";
    header("location: index.php");
}

}
?>
