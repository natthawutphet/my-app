<?php 
require "config/db.php";

$line = "line.php";

$_SESSION['uipb']=$_SERVER['REMOTE_ADDR'];
$uipb = $_SESSION['uipb'];


$check_email = $conn->prepare("SELECT uipb FROM ipb WHERE uipb = :uipb");
$check_email->bindParam(":uipb", $uipb);
$check_email->execute();
$row = $check_email->fetch(PDO::FETCH_ASSOC);

if ($row['uipb'] == $uipb) {
    header("location: https://line.me/R/ti/p/@535apeob");
} else {
   $uipb=$_SERVER['REMOTE_ADDR'];
   $sql = $conn->prepare("INSERT INTO ipb(uipb) VALUES(:uipb)");
   $sql->bindParam(":uipb", $uipb);
   $sql->execute();
   if ($sql) {
    $_SESSION['success'] = "Data has been inserted successfully";
    header("location: https://line.me/R/ti/p/@535apeob");
} else {
    $_SESSION['error'] = "Data has not been inserted successfully";
    header("location: https://line.me/R/ti/p/@535apeob");
}
}


?>




