<?php 
require "config/db.php";

$line = "line.php";

$_SESSION['uipa']=$_SERVER['REMOTE_ADDR'];
$uipa = $_SESSION['uipa'];


$check_email = $conn->prepare("SELECT uipa FROM ipa WHERE uipa = :uipa");
$check_email->bindParam(":uipa", $uipa);
$check_email->execute();
$row = $check_email->fetch(PDO::FETCH_ASSOC);

if ($row['uipa'] == $uipa) {
  
} else {
   $uipa=$_SERVER['REMOTE_ADDR'];
   $sql = $conn->prepare("INSERT INTO ipa(uipa) VALUES(:uipa)");
   $sql->bindParam(":uipa", $uipa);
   $sql->execute();

}


$stmt = $conn->query("SELECT * FROM users");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

 if(isset($row['namea'])){ ?>

<style>
  section {
    display: none;
  }
  header {
    display: block;
  }


</style>

<?php } else {?>
  <style>
  section {
    display: block;
  }
  header {
    display: none;
  }
</style>




  <?php } ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>สินเชื่อเงินด่วน วีแคช 

    </title>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "ImageObject",
          "url": "https://static.wixstatic.com/media/570aa6_4dd7ae823635424f94ea95d83b85a2fb~mv2.jpg/v1/fill/w_640,h_260,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Untitled-4.jpg",
          "width": "800",
          "height": "600"
        }
        </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <style>
    header{
        background:url('img/bg.gif');
        background-attachment: fixed;
    }
</style>
  
  
  </head>
  <body>

  <div class="text-center"><a href="admin">admin</a></div>

    <nav class="navbar bg-body-tertiary">

          <span class="navbar-text ">
             

          </span>
        </div>
      </nav>

      <header>
        <div class="container"> 
             <div class="img w-75 mx-auto">
            <img src="img/22.webp" class="mb-3" width="100%">
          
                                             <a href="<?php echo $line;?>">    <img src="img/btn.gif" class="mb-3" width="100%"></a>
                 <img src="img/03.jpg" class="mb-3" width="100%">
          

                  <a href="<?php echo $line;?>">   <img src="img/line.gif" width="100%"></a>

                  <img src="img/349904034_23854305188340018_1284483484477911945_n.jpg" class="mb-3" width="100%">         





            </div>


        </div>




        
        <div class="fixed-bottom mb-3" ><div class="text-center"><a href="" class="btn btn-success fixed-bottom w-25 mx-auto mb-3 rounded-pill" >ติดต่อสอบถาม</a></div></div>

    </header>
   







<section>  

<div class="comtainer">
  <div class="text-center">
    <h1>ร้าน ตุ๊กตา สวยๆ</h1>
 
<p>ตุ๊กตาม้าโพนี่สุดโด่งดัง เนื้อสัมผัสนุ่มเย็นสบาย กอดนุ่มมากๆ<br>
สำหรับโพนีตัวใหญ่ขนาด 80cm และ 100cm จะสามารถนั่งหรือนอนกอดได้สบายเลยจ้า <br>
เหมาะสำหรับตกแต่งบ้าน แต่งร้าน ให้เป็นของขวัญสุดเซอร์ไพรส์<br>
สามารถกอดนอนเป็นหมอนข้างได้ หรือจะเป็นหมอนไว้หนุนก็นุ่มสบาย
คุณภาพดี รายละเอียดดีมากตามภาพเลยจ้า
คนรักน้องโพนี่ห้ามพลาดเชียว!
โปรโมชั่น! ราคาพิเศษ : 590.00 บาท</p>
<img src="i/product_shop_15390969131.jpg" alt="">
<img src="i/product_shop_15390969132.jpg" alt="">
<img src="i/product_shop_1539096914.jpg" alt="">
<img src="i/product_shop_15390969142.jpg" alt="">
<img src="i/product_shop_1557932578.jpg" alt="">
<img src="i/product_shop_15579325781.jpg" alt="">
<img src="i/product_shop_1557932674.jpg" alt="">
<img src="i/product_shop_1578931718.jpg" alt="">
<img src="i/product_shop_1578931813.jpg" alt="">















</div>
</div>

</section>
















    



<div class="fixed-bottom">
<div class="text-bg-light p-3">
<div class="text-center">  

<a href="<?php echo $line;?>" class="btn btn-success w-50 rounded-pill">ลงทะเบียนเลย</a>
</div>


   </div>
   </div></div>

</body>
</html>