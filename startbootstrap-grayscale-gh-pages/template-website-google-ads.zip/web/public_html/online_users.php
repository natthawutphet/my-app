<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// กำหนดข้อมูลสำหรับเชื่อมต่อฐานข้อมูล MySQLi
$host = 'localhost';  // หรือโฮสต์ของเซิร์ฟเวอร์ฐานข้อมูล
$username = 'root';  // ชื่อผู้ใช้ฐานข้อมูล
$password = '';  // รหัสผ่านฐานข้อมูล
$database = 'class';  // ชื่อฐานข้อมูลที่ใช้

// เชื่อมต่อฐานข้อมูล MySQLi
$connection = new mysqli($host, $username, $password, $database);

// ตรวจสอบว่าเชื่อมต่อฐานข้อมูลสำเร็จหรือไม่
if ($connection->connect_error) {
    die('การเชื่อมต่อฐานข้อมูลล้มเหลว: ' . $connection->connect_error);
}

// สร้าง query เพื่อรับข้อมูลผู้ใช้ออนไลน์
$query = "SELECT COUNT(*) as online_users FROM users WHERE is_online = 1";
$result = mysqli_query($connection, $query);
$row = mysqli_fetch_assoc($result);
$onlineUsers = $row['online_users'];

// ปิดการเชื่อมต่อฐานข้อมูล MySQLi
$connection->close();

// ส่งข้อมูลผู้ใช้ออนไลน์กลับเป็น JSON
echo json_encode($onlineUsers);
?>
<script src="script.js"></script>

</body>
</html>