fetch('online_users.php')
  .then(response => response.text())
  .then(data => {
    const onlineUsers = parseInt(data);  // แปลงค่าเป็นตัวเลขจำนวนเต็ม

    // ใช้ข้อมูลผู้ใช้ออนไลน์ที่ได้รับ
    console.log('จำนวนผู้ใช้ออนไลน์: ', onlineUsers);
    // สามารถทำการแสดงผลในหน้าเว็บได้ตามต้องการ
    // เช่น แสดงจำนวนผู้ใช้ออนไลน์ในตัวหนังสือหรือแสดงในตาราง
  })
  .catch(error => {
    console.error('เกิดข้อผิดพลาดในการเรียกข้อมูลผู้ใช้ออนไลน์: ', error);
  });
