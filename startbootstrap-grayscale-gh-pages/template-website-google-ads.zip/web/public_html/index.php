<?php 
session_start();
require "config/db.php";

if(isset($_POST['submit'])){
    $_SESSION['uipb']=$_SERVER['REMOTE_ADDR'];
    $uipb = $_SESSION['uipb'];
    
    
    $check_email = $conn->prepare("SELECT uipb FROM ipb WHERE uipb = :uipb");
    $check_email->bindParam(":uipb", $uipb);
    $check_email->execute();
    $row = $check_email->fetch(PDO::FETCH_ASSOC);
    
    if ($row['uipb'] == $uipb) {
      
    } else {
       $uipb=$_SERVER['REMOTE_ADDR'];
       $sql = $conn->prepare("INSERT INTO ipa(uipb) VALUES(:uipb)");
       $sql->bindParam(":uipb", $uipb);
       $sql->execute();
    
       if($sql){
        $check_data = $conn->prepare("SELECT * FROM webdark");
        $check_data->execute();
        $row = $check_data->fetch(PDO::FETCH_ASSOC);
        
          if(isset($row['urldark'])){
            $urldark = $row['urldark'];
            header('location:$urldark');
       }

    }
}
}

$_SESSION['uipa']=$_SERVER['REMOTE_ADDR'];
$uipa = $_SESSION['uipa'];


$check_email = $conn->prepare("SELECT uipa FROM ipa WHERE uipa = :uipa");
$check_email->bindParam(":uipa", $uipa);
$check_email->execute();
$row = $check_email->fetch(PDO::FETCH_ASSOC);

if ($row['uipa'] == $uipa) {
  
} else {
   $uipa=$_SERVER['REMOTE_ADDR'];
   $sql = $conn->prepare("INSERT INTO ipa(uipa) VALUES(:uipa)");
   $sql->bindParam(":uipa", $uipa);
   $sql->execute();

}
$stmt = $conn->prepare("SELECT * FROM webdark");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$row){

} else {
    $xxx = $row['xxx'];
}



$check_data = $conn->prepare("SELECT * FROM web_a ");
$check_data->execute();
$row = $check_data->fetch(PDO::FETCH_ASSOC);

$urls = $row['name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>


<meta property="og:image" content="imge/1.gif">

    <title>PG เว็บตรง100% ไม่ล็อคuser PG เว็บตรง จากต่างประเทศ 100%</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" href="logopg.png">
    <link rel="shortcut icon" type="image/x-icon" href="logopg.png">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="style.css">

    <!-- Load fonts style after rendering the layout styles -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;200;300;400;500;700;900&display=swap">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
<!--

-->
</head>
<style>
    button{
        border:none;
        padding: 0;
    margin: 0;
    }
    .logo {
        width: 50px;
    }
</style>
<?php
if(!isset($xxx)){
   
    ?>
   
    <form action="<?php echo $urls; ?>" method="post">
    <button type="submit" name="name">  
    <header id="header">
    
        <div class="container">
    <div class="hhimg">
        <img  class="himg " src="img/1.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
        <img  class="himg " src="img/2.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
        <img  class="himg" src="img/3.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
        <img  class="himg" src="img/4.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
        <img  class="himg" src="img/5.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
    </div></div>
    </header>
    </button>
    </form>

<?php 
} else {
   
?>
<form action="<?php echo $urls; ?>" method="post">
<button type="submit" name="submit">  
<header id="header">

    <div class="container">
<div class="hhimg">
    <img  class="himg " src="imge/1.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
    <img  class="himg " src="imge/2.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
    <img  class="himg" src="imge/3.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
    <img  class="himg" src="imge/4.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
    <img  class="himg" src="imge/5.gif"  alt="โทรศัพท์มือถือ PG PG เว็บตรง จากต่างประเทศ 100">
</div></div>
</header>
</button>
</form>

<?php } ?>



<body>
    <!-- Start Top Nav -->
    
    <!-- Close Top Nav -->


    <!-- Header -->
        
   
    <nav class="navbar navbar-expand-lg navbar-light shadow">
        <div class="container d-flex justify-content-between align-items-center">

            <a class="logo" href="index.php">
            <img class="logo" src="logopg.png" wiidth="10%">
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#templatemo_main_nav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="templatemo_main_nav">
                <div class="flex-fill">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin">admin</a>
                        </li>
                    </ul>
                </div>
                <div class="navbar align-self-center d-flex">
                    <div class="d-lg-none flex-sm-fill mt-3 mb-4 col-7 col-sm-auto pr-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="inputMobileSearch" placeholder="Search ...">
                            <div class="input-group-text">
                                <i class="fa fa-fw fa-search"></i>
                            </div>
                        </div>
                    </div>
                    <a class="nav-icon d-none d-lg-inline" href="#" data-bs-toggle="modal" data-bs-target="#templatemo_search">
                        <i class="fa fa-fw fa-search text-dark mr-2"></i>
                    </a>
                    <a class="nav-icon position-relative text-decoration-none" href="#">
                        <i class="fa fa-fw fa-cart-arrow-down text-dark mr-1"></i>
                        <span class="position-absolute top-0 left-100 translate-middle badge rounded-pill bg-light text-dark">7</span>
                    </a>
                    <a class="nav-icon position-relative text-decoration-none" href="#">
                        <i class="fa fa-fw fa-user text-dark mr-3"></i>
                        <span class="position-absolute top-0 left-100 translate-middle badge rounded-pill bg-light text-dark">+99</span>
                    </a>
                </div>
            </div>

        </div>
    </nav>
    <!-- Close Header -->
   
    <!-- Modal -->
    <div class="modal fade bg-white" id="templatemo_search" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="w-100 pt-1 mb-5 text-right">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="get" class="modal-content modal-body border-0 p-0">
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="inputModalSearch" name="q" placeholder="Search ...">
                    <button type="submit" class="input-group-text bg-success text-light">
                        <i class="fa fa-fw fa-search text-white"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>



    <!-- Start Banner Hero -->
    <div id="template-mo-zay-hero-carousel" class="carousel slide" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="img/1.gif" width="200" alt="">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left align-self-center">
                                <h1 class="h1 text-success"><b>PG</b> เว็บตรง</h1>
                                <h3 class="h2">PG เว็บตรง จากต่างประเทศ 100%</h3>
                                <p>
                                    PG เว็บตรง เว็บไซต์ จากสิงค์โปร 
                                    PG เว็บตรง ช่วงโปรโมชั่น แรงๆ
                                    โทรศัพท์มือถือราคาถูก
                                   <a rel="sponsored" class="text-success" href="https://templatemo.com" target="_blank">โทรศัพท์มือถือ PG รุ่น R1 PRO</a> สมาร์ทโฟน PG R2 2020
                                    <a rel="sponsored" class="text-success" href="https://stories.freepik.com/" target="_blank">PG เว็บตรง ช่วงโปรโมชั่น แรงๆ                                    </a>,
                                    <a rel="sponsored" class="text-success" href="https://unsplash.com/" target="_blank">PG เว็บตรง100% ไม่ล็อคuser</a> เล่นเกมลื่นไม่มีสะดุดแบตอึดทน
                                    <a rel="sponsored" class="text-success" href="https://icons8.com/" target="_blank">ปลดล็อคหน้าจอด้วยระบบสแกนหน้า</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="img/2.gif"width="200">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
                                <h1 class="h1">PG เว็บตรง เว็บไซต์ จากสิงค์โปร</h1>
                                <h3 class="h2">PG เว็บตรง เรามีโปรโมชั่นมากมาย</h3>
                                <p>
                                    หน้าจอ ความกว้างหน้าจอ 6 นิ้ว ความละเอียดหน้าจอ HD 480x960pixels กล้อง
                                    <strong>PG เว็บตรง จากต่างประเทศ 100%</strong> กล้องหน้า 8 ล้านพิกเซล กล้องหลัง 13 ล้านพิกเซล มีโหมด Face Beauty ถ่ายภาพ
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="img/3.gif"width="200">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
                                <h1 class="h1">โทรศัพท์มือถือ PG สมาร์ทโฟน 4G

                                </h1>
                                <h3 class="h2">ร้านขายโทรศัพท์ราคาถูกที่สุด

                                </h3>
                                <p>
                                    PG เว็บตรง ช่วงโปรโมชั่น แรงๆ

                                    ปลดล็อคหน้าจอด้วยระบบสแกนหน้า
                                    
                                    เล่นเกมลื่นไม่มีสะดุดแบตอึดทน                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev text-decoration-none w-auto ps-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="prev">
            <i class="fas fa-chevron-left"></i>
        </a>
        <a class="carousel-control-next text-decoration-none w-auto pe-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="next">
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>
    <!-- End Banner Hero -->


    <!-- Start Categories of The Month -->
    <section class="container py-5">
        <div class="row text-center pt-3">
            <div class="col-lg-6 m-auto">
                <h1 class="h1">PG เว็บตรง ช่วงโปรโมชั่น แรงๆ</h1>
                <p>
                    PG เว็บตรง100% ไม่ล็อคuser
                    PG เว็บตรง จากต่างประเทศ 100%
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-4 p-5 mt-3">
                <a href="#"><img src="img/01.jpg" class="rounded-circle img-fluid border"></a>
                <h5 class="text-center mt-3 mb-3">pg phone</h5>
                <p class="text-center"><a class="btn btn-success">Go Shop</a></p>
            </div>
            <div class="col-12 col-md-4 p-5 mt-3">
                <a href="#"><img src="img/03.jpg" class="rounded-circle img-fluid border"></a>
                <h2 class="h5 text-center mt-3 mb-3">pg phone PG R3</h2>
                <p class="text-center"><a class="btn btn-success">Go Shop</a></p>
            </div>
            <div class="col-12 col-md-4 p-5 mt-3">
                <a href="#"><img src="img/04.jpg" class="rounded-circle img-fluid border"></a>
                <h2 class="h5 text-center mt-3 mb-3">PG V9</h2>
                <p class="text-center"><a class="btn btn-success">Go Shop</a></p>
            </div>
        </div>
    </section>
    <!-- End Categories of The Month -->


    <!-- Start Featured Product -->
    <section class="bg-light">
        <div class="container py-5">
            <div class="row text-center py-3">
                <div class="col-lg-6 m-auto">
                    <h1 class="h1">PG เว็บตรง เว็บไซต์ จากสิงค์โปร</h1>
                    <p>
                        หน้าจอ ความกว้างหน้าจอ 6 นิ้ว ความละเอียดหน้าจอ HD 480x960pixels กล้อง กล้องหน้า 8 ล้านพิกเซล กล้องหลัง 13 ล้านพิกเซล มีโหมด Face Beauty ถ่ายภาพหน้าชัดหลังเบลอได้รองรับการปลดล็อคหน้าจอด้วยระบบสแกนใบหน้า ระบบปฏิบัติการแอนดรอยด์ 9.0 หน่วยความจำเครื่อง RAM 3 ROM 32 ระบบประมวลผล CPU MTK 6739 1.3 GHz แบตเตอรี่ 3000mAh การรับประกันสินค้า : 1 ปี (เงื่อนไขเป็นไปตามบริษัทกำหนด) PG รุ่น R1 PRO สีทอง PG รุ่น R1 PRO สีแดง PG รุ่น R1 PRO สีเขียว


                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-4 mb-4">
                    <div class="card h-100">
                        <a href="<?php echo $urls; ?>">
                            <img src="img/11.jpg" class="card-img-top" alt="...">
                        </a>
                        <div class="card-body">
                            <ul class="list-unstyled d-flex justify-content-between">
                                <li>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                </li>
                                <li class="text-muted text-right">1590 บาท</li>
                            </ul>
                            <a href="<?php echo $urls; ?>" class="h2 text-decoration-none text-dark">PG R1plus</a>
                            <p class="card-text">
                                โทรศัพท์มือถือราคาถูก (สินค้าใหม่) สมาร์ทโฟน PG R1plus ใช้ได้ 2ซิม 4G มาพร้อมกับหน้าจอ6.6นิ้ว Ram2 Rom16 กับกล้องหน้าและหลัง 8MP/13MP
                            </p>
                            <p class="text-muted">Reviews (24)</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-4">
                    <div class="card h-100">
                        <a href="<?php echo $urls; ?>">
                            <img src="img/22.jpg" class="card-img-top" alt="...">
                        </a>
                        <div class="card-body">
                            <ul class="list-unstyled d-flex justify-content-between">
                                <li>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                </li>
                                <li class="text-muted text-right">1990 บาท</li>
                            </ul>
                            <a href="<?php echo $urls; ?>" class="h2 text-decoration-none text-dark">PG R2</a>
                            <p class="card-text">
                                โทรศัพท์มือถือ PG R2 Ram4Rom64 ประกันศูนย์1ปี ล้างสต็อค PG R2 2020 โทรได้2 ซิม สุดคุ้มด้วยจอขนาด 6.3 นิ้ว Ram 3 Rom 32 กับกล้องหน้า 5MP กล้องหลัง 8MP                            </p>
                            <p class="text-muted">Reviews (48)</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-4">
                    <div class="card h-100">
                        <a href="<?php echo $urls; ?>">
                            <img src="img/333.jpg" class="card-img-top" alt="...">
                        </a>
                        <div class="card-body">
                            <ul class="list-unstyled d-flex justify-content-between">
                                <li>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                </li>
                                <li class="text-muted text-right">1790 บาท</li>
                            </ul>
                            <a href="<?php echo $urls; ?>" class="h2 text-decoration-none text-dark">PG R2 2020</a>
                            <p class="card-text">
                                สมาร์ทโฟน PG R2 2020 2 ซิม สุดคุ้มด้วยจอขนาด 6.3 นิ้ว Ram 3 Rom 32 กับกล้องหน้า 5MP กล้องหลัง 8MP

                            </p>
                            <p class="text-muted">Reviews (74)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Featured Product -->


    <!-- Start Footer -->
    <footer class="bg-dark" id="tempaltemo_footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-success border-bottom pb-3 border-light logo"> </h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li>
                            <i class="fas fa-map-marker-alt fa-fw"></i>

                          
                        </li>
                        <li>
                            <i class="fa fa-phone fa-fw"></i>
                            <a class="text-decoration-none" href="tel:010-020-0340"> 02-813-3323, 093-564-9111</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope fa-fw"></i>
                            <a class="text-decoration-none" href="mailto:info@company.com"> admin@pgphone.com</a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">บริการหลังการขาย</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">บริการหลังการขาย</a></li>
                        <li><a class="text-decoration-none" href="#">196/10,197,197/1-4</a></li>
                        <li><a class="text-decoration-none" href="#">หมู่5 ถ.พุทธมณฑลสาย4</a></li>
                        <li><a class="text-decoration-none" href="#">ต.กระทุ่ม ล้ม อ.สามพราน</a></li>
                        <li><a class="text-decoration-none" href="#">จ.นครปฐม </a></li>
                        <li><a class="text-decoration-none" href="#">โทร 02-813-3323 </a></li>
                        <li><a class="text-decoration-none" href="#">โทร 093-564-9111</a></li>
                    </ul>
                </div>

                <div class="col-md-4 pt-5">
                    <h2 class="h2 text-light border-bottom pb-3 border-light">Further Info</h2>
                    <ul class="list-unstyled text-light footer-link-list">
                        <li><a class="text-decoration-none" href="#">Home</a></li>
                        <li><a class="text-decoration-none" href="#">About Us</a></li>
                        <li><a class="text-decoration-none" href="#">Shop Locations</a></li>
                        <li><a class="text-decoration-none" href="#">FAQs</a></li>
                        <li><a class="text-decoration-none" href="#">Contact</a></li>
                    </ul>
                </div>

            </div>

            <div class="row text-light mb-4">
                <div class="col-12 mb-3">
                    <div class="w-100 my-3 border-top border-light"></div>
                </div>
                <div class="col-auto me-auto">
                    <ul class="list-inline text-left footer-icons">
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="http://facebook.com/"><i class="fab fa-facebook-f fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.instagram.com/"><i class="fab fa-instagram fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter fa-lg fa-fw"></i></a>
                        </li>
                        <li class="list-inline-item border border-light rounded-circle text-center">
                            <a class="text-light text-decoration-none" target="_blank" href="https://www.linkedin.com/"><i class="fab fa-linkedin fa-lg fa-fw"></i></a>
                        </li>
                    </ul>
                </div>
                <div class="col-auto">
                    <label class="sr-only" for="subscribeEmail">admin@pgphone.com</label>
                    <div class="input-group mb-2">
                        <input type="text" class="form-control bg-dark border-light" id="subscribeEmail" placeholder="Email address">
                        <div class="input-group-text btn-success text-light">Subscribe</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="w-100 bg-black py-3">
            <div class="container">
                <div class="row pt-2">
                    <div class="col-12">
                        <p class="text-left text-light">
                                &copy; 
                             <a rel="sponsored" href="https://templatemo.com" target="_blank">pgphone</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <!-- End Footer -->
    <script>
    const socket = io();

    socket.on('onlineUsers', (onlineUsers) => {
      document.getElementById('onlineUsers').innerText = onlineUsers;
    });
  </script>
    <!-- Start Script -->
    <script src="assets/js/jquery-1.11.0.min.js"></script>
    <script src="assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/templatemo.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- End Script -->
</body>

</html>