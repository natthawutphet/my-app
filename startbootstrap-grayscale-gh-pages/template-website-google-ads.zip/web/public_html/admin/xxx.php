<?php 
session_start();

if(isset($_GET['submit'])){
    $_SESSION['ipa']="ok";
    header('location:index.php');
}
if(isset($_GET['xxx'])){
    unset($_SESSION['ipa']);
    header('location:index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
body {
    position: relative;

}
#box {
      
    border: 1px solid rgb(0, 0, 0);
    width: 500px;
    
position: absolute;
left: 100px;
top: 200px;

}
#boxx {
      
    border: 1px solid rgb(0, 0, 0);
    width: 500px;
    
position: absolute;
left: 1300px;
top: 200px;

}
#mitter {
      
    border: 1px solid reb;
    width: 300px;
    
position: absolute;
left: 45%;
top: 80%;

}
 </style>

</head>
<body>




    


<div class="h1" id="xx">

<?php  require "../config/db.php"; 
         $stmt = $conn->query("SELECT * FROM ipa");
         $stmt->execute();
         $users = $stmt->fetchAll();
     ?>
                          หน้าแรก <br>
 <div id="xx " class="btn btn-info rounded-pill" ><h2> > > <?php $num_a = $stmt->rowCount(); echo $num_a;?> < < </h2></div>
</button>
<?php
$stmt = $conn->query("SELECT * FROM ipa");
$stmt->execute();
$users = $stmt->fetchAll();

if (!$users) {
   
} else {
foreach($users as $user)  {  


if(isset($_SESSION['ipa'])){?>

<div id="box">  
<table class="table table-bordered border-primary">

  <tr>  <td><?php echo $user['id']; ?> </td>
    <td><?php echo $user['uipa']; ?> </td>
    <td><?php echo $user['time']; ?></td>
</tr>

    </table>


</div>

    
<?php } ?>



<?php   }} ?>


</div>





<div class="h1" id="xxx">
<?php  require "../config/db.php"; 
         $stmt = $conn->query("SELECT * FROM ipb");
         $stmt->execute();
         $users = $stmt->fetchAll();
     ?>
 หน้า2 <br>
<div id="xxx" class="btn btn-info rounded-pill" ><h2> > > <?php $num_b =$stmt->rowCount(); echo $num_b;?> < < </h2></div>
<?php
$stmt = $conn->query("SELECT * FROM ipb");
$stmt->execute();
$users = $stmt->fetchAll();

if (!$users) {
   
} else {
foreach($users as $user)  {  

if(isset($_SESSION['ipa'])){?>

<div id="boxx">  
<table class="table table-bordered border-primary">

  <tr>  <td><?php echo $user['id']; ?> </td>
    <td><?php echo $user['uipb']; ?> </td>
    <td><?php echo $user['time']; ?></td>
</tr>

    </table>


</div>


<?php   }} }?>
</div>


<div id="mitter" class="mitter"></div>


</body>
</html>

