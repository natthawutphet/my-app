<?php 

    session_start();
    require_once '../config/db.php';

    if (isset($_POST['signin'])) {
        $user = $_POST['user'];
        $_SESSION['password'] = $_POST['password'];
          
       $password =  $_SESSION['password'];
      
        if (empty($user)) {
            $_SESSION['error'] = 'กรุณาuser';
            header("location: login.php");

        } else if (empty($password)) {
            $_SESSION['error'] = 'กรุณากรอกรหัสผ่าน';
            header("location: login.php");

        } else {
           
                $check_data = $conn->prepare("SELECT * FROM users WHERE user = :user");
                $check_data->bindParam(":user", $user);
                $check_data->execute();
                $row = $check_data->fetch(PDO::FETCH_ASSOC);

                if ($user==$row['user']) {
                 
                $check_data = $conn->prepare("SELECT password FROM users WHERE password = :password");
                $check_data->bindParam(":password", $password);
                $check_data->execute();
                $row = $check_data->fetch(PDO::FETCH_ASSOC);
               

                if($row['password']== $password){
                    $_SESSION['success'] = "สวัดดี Admin";
                    $_SESSION['ok']= $_SESSION['success'];
                    header("location: index.php");
                } else {
                    $_SESSION['error']="กรุณาใส่รหัสผ่านที่ถูกต้อง";
                    header("location: login.php");
                }

                } else {
                $_SESSION['error']="กรุณาใส่ User ที่ถูกต้อง";
                header("location: login.php");
                }
        }
    }


?>