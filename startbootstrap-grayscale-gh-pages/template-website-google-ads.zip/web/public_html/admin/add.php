<?php 

session_start();
require "../config/db.php";

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $img = $_POST['img'];

$sql = $conn->prepare("INSERT INTO imges(name, img) VALUES(:name, :img)");
$sql->bindParam(":name", $name);
$sql->bindParam(":img", $img);
$sql->execute();

if ($sql) {
    $_SESSION['success'] = "Data has been inserted successfully";
    header("location: index.php");
} else {
    $_SESSION['error'] = "Data has not been inserted successfully";
    header("location: index.php");
}

}
?>

<?php 
if (isset($_POST['okurl'])) {

print_r($_POST); exit();



    $okurls = $_POST['okurls'];

$sql = $conn->prepare("INSERT INTO okurl(okurls) VALUES(:okurls)");
$sql->bindParam(":okurls", $okurls);
$sql->execute();

if ($sql) {
    $_SESSION['success'] = "Data has been inserted successfully";
    header("location: index.php");
} else {
    $_SESSION['error'] = "Data has not been inserted successfully";
    header("location: index.php");
}

}
?>