<?php 

    session_start();
    unset($_SESSION['ok']);
    unset($_SESSION['ok']);
    header('location: index.php');

?>