<?php session_start();
require "config/db.php";

if (!isset($_SESSION['user'])){
    header("location: index.php");
} else {
    $stmt = $conn->prepare("SELECT * FROM webdark");
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$row) {
    header("location:index.php");
} else {
    $xxx = $row['xxx'];
    header("location:$xxx");
}




}


?>