-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2023 at 06:35 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pgauto`
--

-- --------------------------------------------------------

--
-- Table structure for table `bg`
--

CREATE TABLE `bg` (
  `id` int(11) NOT NULL,
  `img` varchar(250) NOT NULL,
  `xname` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `bg`
--

INSERT INTO `bg` (`id`, `img`, `xname`) VALUES
(8, '1510672560.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `ipa`
--

CREATE TABLE `ipa` (
  `id` int(10) NOT NULL,
  `uipa` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ipa`
--

INSERT INTO `ipa` (`id`, `uipa`, `time`) VALUES
(3187, '::1', '2023-06-06 03:11:06'),
(3188, '192.168.1.116', '2023-06-06 03:16:52');

-- --------------------------------------------------------

--
-- Table structure for table `ipb`
--

CREATE TABLE `ipb` (
  `id` int(10) NOT NULL,
  `uipb` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `ipb`
--

INSERT INTO `ipb` (`id`, `uipb`, `time`) VALUES
(2099, '192.168.1.118', '2023-06-06 04:15:58');

-- --------------------------------------------------------

--
-- Table structure for table `moblie`
--

CREATE TABLE `moblie` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `moblie`
--

INSERT INTO `moblie` (`id`, `name`, `price`, `img`) VALUES
(8, 'PG R1 หน้าจอ 6.3', '1790', '1.jpg'),
(10, 'PG รุ่น R1 PRO\r\n', '1990', 'p2.jpg\r\n'),
(11, 'PG R1plus', '1590 ', '11.jpg'),
(12, 'PG V9 Plus\n', '1990', '22.jpg\n'),
(13, 'PG R2 2020', '1590', '33.jpg'),
(14, 'PG R2\r\n', '1990', '001.jpg'),
(15, 'PG V9', '1990', '002.jpg'),
(16, 'PG R3\r\n', '1590', '003.jpg'),
(17, 'PG R1 s\n', '1590', '005.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user` varchar(250) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user`, `password`) VALUES
(1, '', ''),
(2, 'admin', '1111');

-- --------------------------------------------------------

--
-- Table structure for table `webdark`
--

CREATE TABLE `webdark` (
  `id` int(11) NOT NULL,
  `xxx` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `webdark`
--

INSERT INTO `webdark` (`id`, `xxx`) VALUES
(15, 'https://www.youtube.com/watch?v=obH7GfWMR7w');

-- --------------------------------------------------------

--
-- Table structure for table `web_a`
--

CREATE TABLE `web_a` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `web_a`
--

INSERT INTO `web_a` (`id`, `name`) VALUES
(13, 'http://192.168.1.118/web/2/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ipa`
--
ALTER TABLE `ipa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ipb`
--
ALTER TABLE `ipb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webdark`
--
ALTER TABLE `webdark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `web_a`
--
ALTER TABLE `web_a`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ipa`
--
ALTER TABLE `ipa`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3189;

--
-- AUTO_INCREMENT for table `ipb`
--
ALTER TABLE `ipb`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2100;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `webdark`
--
ALTER TABLE `webdark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `web_a`
--
ALTER TABLE `web_a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
